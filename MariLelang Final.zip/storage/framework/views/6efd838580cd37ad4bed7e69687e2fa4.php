<?php $__env->startSection('title', isset($kategori) ? 'Edit Kategori' : 'Tambah Kategori'); ?>
<?php $__env->startSection('content'); ?>
<div style="max-width:480px;">
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:24px;">
        <a href="<?php echo e(route('admin.kategori.index')); ?>" style="color:var(--text-muted); text-decoration:none; font-size:13px;"><i class="bi bi-arrow-left"></i> Kembali</a>
        <h2 style="font-size:20px; font-weight:800;"><?php echo e(isset($kategori) ? 'Edit Kategori' : 'Tambah Kategori'); ?></h2>
    </div>
    <div style="background:white; border-radius:12px; border:1px solid var(--border); padding:28px;">
        <form method="POST" action="<?php echo e(isset($kategori) ? route('admin.kategori.update', $kategori->id_kategori) : route('admin.kategori.store')); ?>">
            <?php echo csrf_field(); ?> <?php if(isset($kategori)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div style="margin-bottom:18px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Nama Kategori</label>
                <input type="text" name="nama_kategori" value="<?php echo e(old('nama_kategori', $kategori->nama_kategori ?? '')); ?>" maxlength="50" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit;">
                <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div style="margin-bottom:24px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">Deskripsi (opsional)</label>
                <textarea name="deskripsi_kategori" maxlength="255" style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit; resize:vertical; min-height:80px;"><?php echo e(old('deskripsi_kategori', $kategori->deskripsi_kategori ?? '')); ?></textarea>
            </div>
            <button type="submit" style="padding:12px 28px; background:var(--brand); color:white; border:none; border-radius:8px; font-size:14px; font-weight:700; cursor:pointer; font-family:inherit;">
                <?php echo e(isset($kategori) ? 'Simpan Perubahan' : 'Tambah Kategori'); ?>

            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/admin/kategori/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', isset($barang) ? 'Edit Barang' : 'Tambah Barang'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:640px;">
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:24px;">
        <a href="<?php echo e(route('petugas.barang.index')); ?>" style="color:var(--text-muted); text-decoration:none; font-size:13px;"><i class="bi bi-arrow-left"></i> Kembali</a>
        <h2 style="font-size:20px; font-weight:800;"><?php echo e(isset($barang) ? 'Edit Barang' : 'Tambah Barang'); ?></h2>
    </div>

    <div style="background:white; border-radius:12px; border:1px solid var(--border); padding:28px;">
        <form id="form-edit-barang" method="POST" action="<?php echo e(isset($barang) ? route('petugas.barang.update', $barang->id_barang) : route('petugas.barang.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($barang)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <?php
            $field = fn($name, $label, $type='text', $extra='') => '
            <div style="margin-bottom:18px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">'.$label.'</label>
                <input type="'.$type.'" name="'.$name.'" value="'.e(old($name, isset($barang) ? $barang->$name : '')).'" '.$extra.' style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit; outline:none;">
                @error(\''.$name.'\') <span style="color:#DC2626; font-size:12px;">{{ $message }}</span> @enderror
            </div>';
            ?>

            
            <div style="margin-bottom:18px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">ID Barang</label>
                <input type="text" value="<?php echo e(isset($barang) ? str_pad($barang->id_barang,4,'0',STR_PAD_LEFT) : str_pad($nextId,4,'0',STR_PAD_LEFT)); ?>" readonly
                    style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit; background:#F8FAFC; color:var(--text-muted); cursor:not-allowed;">
                <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">ID otomatis, tidak dapat diubah.</div>
            </div>

            <div style="margin-bottom:18px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Nama Barang</label>
                <input type="text" name="nama_barang" value="<?php echo e(old('nama_barang', $barang->nama_barang ?? '')); ?>" maxlength="25" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit;">
                <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;">
                <div>
                    <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Tanggal</label>
                    <input type="date" name="tgl" value="<?php echo e(old('tgl', isset($barang) ? $barang->tgl : '')); ?>" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit;">
                    <?php $__errorArgs = ['tgl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Harga Awal (Rp)</label>
                    <input type="number" name="harga_awal" value="<?php echo e(old('harga_awal', $barang->harga_awal ?? '')); ?>" min="0" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit;">
                    <?php $__errorArgs = ['harga_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div style="margin-bottom:18px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Deskripsi</label>
                <textarea name="deskripsi_barang" maxlength="100" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit; resize:vertical; min-height:80px;"><?php echo e(old('deskripsi_barang', $barang->deskripsi_barang ?? '')); ?></textarea>
                <?php $__errorArgs = ['deskripsi_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;">
                <div>
                    <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Kategori</label>
                    <select name="id_kategori" required style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; font-size:14px; font-family:inherit;">
                        <option value="">-- Pilih Kategori --</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id_kategori); ?>" <?php echo e(old('id_kategori', $barang->id_kategori ?? '') == $k->id_kategori ? 'selected' : ''); ?>><?php echo e($k->nama_kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Kondisi</label>
                    <div style="display:flex; gap:16px; padding-top:10px;">
                        <label style="display:flex; align-items:center; gap:6px; font-size:14px; cursor:pointer;">
                            <input type="radio" name="kondisi" value="baru" <?php echo e(old('kondisi', $barang->kondisi ?? '') === 'baru' ? 'checked' : ''); ?>> Baru
                        </label>
                        <label style="display:flex; align-items:center; gap:6px; font-size:14px; cursor:pointer;">
                            <input type="radio" name="kondisi" value="bekas" <?php echo e(old('kondisi', $barang->kondisi ?? 'bekas') === 'bekas' ? 'checked' : ''); ?>> Bekas
                        </label>
                    </div>
                    <?php $__errorArgs = ['kondisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div style="margin-bottom:24px;">
                <label style="display:block; font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.5px;">Foto Barang</label>
                <?php if(isset($barang) && $barang->foto_barang): ?>
                <img src="<?php echo e($barang->foto_url); ?>" id="preview" style="width:120px; height:90px; object-fit:cover; border-radius:8px; border:1px solid var(--border); margin-bottom:8px; display:block;">
                <?php else: ?>
                <img id="preview" style="display:none; width:120px; height:90px; object-fit:cover; border-radius:8px; border:1px solid var(--border); margin-bottom:8px;">
                <?php endif; ?>
                <input type="file" name="foto_barang" accept="image/jpg,image/jpeg,image/png,image/webp" onchange="previewImg(this)" style="font-size:13px;">
                <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">JPG, PNG, WebP. Maks 2MB.</div>
                <?php $__errorArgs = ['foto_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:#DC2626; font-size:12px;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if(isset($barang)): ?>
            <button type="button" onclick="document.getElementById('modal-simpan').style.display='flex'" style="padding:12px 28px; background:var(--brand); color:white; border:none; border-radius:8px; font-size:14px; font-weight:700; cursor:pointer; font-family:inherit;">
                Simpan Perubahan
            </button>
            <?php else: ?>
            <button type="button" onclick="document.getElementById('modal-tambah').style.display='flex'" style="padding:12px 28px; background:var(--brand); color:white; border:none; border-radius:8px; font-size:14px; font-weight:700; cursor:pointer; font-family:inherit;">
                <i class="bi bi-plus-lg"></i> Tambah Barang
            </button>
            <?php endif; ?>
        </form>
    </div>
</div>


<div id="modal-tambah" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:white; border-radius:20px; padding:36px 32px; width:100%; max-width:360px; text-align:center; box-shadow:0 20px 60px rgba(0,0,0,.2);">
        <div style="width:64px; height:64px; background:#F0FDF4; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; font-size:28px; color:#16A34A;">
            <i class="bi bi-box-seam"></i>
        </div>
        <h3 style="font-size:18px; font-weight:800; color:#0F172A; margin-bottom:8px;">Tambah Barang?</h3>
        <p style="font-size:13px; color:#64748B; margin-bottom:28px;">Pastikan semua data barang sudah benar sebelum ditambahkan ke sistem.</p>
        <div style="display:flex; gap:10px;">
            <button onclick="document.getElementById('modal-tambah').style.display='none'" style="flex:1; padding:11px; border:1.5px solid #E2E8F0; border-radius:10px; font-size:14px; font-weight:700; color:#64748B; background:white; cursor:pointer; font-family:inherit;">
                Batal
            </button>
            <button onclick="document.getElementById('form-edit-barang').submit()" style="flex:1; padding:11px; border:none; border-radius:10px; font-size:14px; font-weight:700; color:white; background:#16A34A; cursor:pointer; font-family:inherit;">
                <i class="bi bi-check-lg"></i> Ya, Tambah
            </button>
        </div>
    </div>
</div>


<div id="modal-simpan" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:white; border-radius:20px; padding:36px 32px; width:100%; max-width:360px; text-align:center; box-shadow:0 20px 60px rgba(0,0,0,.2);">
        <div style="width:64px; height:64px; background:#EEF2FF; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; font-size:28px; color:var(--brand);">
            <i class="bi bi-floppy"></i>
        </div>
        <h3 style="font-size:18px; font-weight:800; color:#0F172A; margin-bottom:8px;">Simpan Perubahan?</h3>
        <p style="font-size:13px; color:#64748B; margin-bottom:28px;">Perubahan data barang akan disimpan dan tidak dapat dibatalkan.</p>
        <div style="display:flex; gap:10px;">
            <button onclick="document.getElementById('modal-simpan').style.display='none'" style="flex:1; padding:11px; border:1.5px solid #E2E8F0; border-radius:10px; font-size:14px; font-weight:700; color:#64748B; background:white; cursor:pointer; font-family:inherit;">Batal</button>
            <button onclick="document.getElementById('form-edit-barang').submit()" style="flex:1; padding:11px; border:none; border-radius:10px; font-size:14px; font-weight:700; color:white; background:var(--brand); cursor:pointer; font-family:inherit;">
                <i class="bi bi-floppy"></i> Simpan
            </button>
        </div>
    </div>
</div>

<script>
function previewImg(input) {
    const preview = document.getElementById('preview');
    if (input.files && input.files[0]) {
        preview.src = URL.createObjectURL(input.files[0]);
        preview.style.display = 'block';
    }
}
document.getElementById('modal-simpan') && document.getElementById('modal-simpan').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
});
document.getElementById('modal-tambah').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/petugas/barang/form.blade.php ENDPATH**/ ?>
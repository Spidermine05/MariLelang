<?php $__env->startSection('title', 'Cari Lelang'); ?>
<?php $__env->startSection('content'); ?>
<div style="padding:24px; display:grid; grid-template-columns:260px 1fr; gap:24px; align-items:start;">
    
    <div style="background:white; border-radius:14px; border:1px solid #E2E8F0; padding:20px; position:sticky; top:80px;">
        <h3 style="font-size:14px; font-weight:800; margin-bottom:16px;">Filter Pencarian</h3>
        <form method="GET" action="<?php echo e(route('masyarakat.lelang.search')); ?>">
            <div style="margin-bottom:14px;">
                <label style="display:block; font-size:11px; font-weight:700; color:#64748B; margin-bottom:6px; text-transform:uppercase;">Kata Kunci</label>
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Nama barang..." style="width:100%; padding:8px 10px; border:1px solid #E2E8F0; border-radius:8px; font-size:13px; font-family:inherit;">
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block; font-size:11px; font-weight:700; color:#64748B; margin-bottom:6px; text-transform:uppercase;">Kategori</label>
                <select name="id_kategori" style="width:100%; padding:8px 10px; border:1px solid #E2E8F0; border-radius:8px; font-size:13px; font-family:inherit;">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id_kategori); ?>" <?php echo e(request('id_kategori') == $k->id_kategori ? 'selected' : ''); ?>><?php echo e($k->nama_kategori); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block; font-size:11px; font-weight:700; color:#64748B; margin-bottom:6px; text-transform:uppercase;">Harga Min (Rp)</label>
                <input type="number" name="harga_min" value="<?php echo e(request('harga_min')); ?>" min="0" style="width:100%; padding:8px 10px; border:1px solid #E2E8F0; border-radius:8px; font-size:13px; font-family:inherit;">
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block; font-size:11px; font-weight:700; color:#64748B; margin-bottom:6px; text-transform:uppercase;">Harga Max (Rp)</label>
                <input type="number" name="harga_max" value="<?php echo e(request('harga_max')); ?>" min="0" style="width:100%; padding:8px 10px; border:1px solid #E2E8F0; border-radius:8px; font-size:13px; font-family:inherit;">
            </div>
            <button type="submit" style="width:100%; padding:10px; background:#4F46E5; color:white; border:none; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer; font-family:inherit;">Cari</button>
            <a href="<?php echo e(route('masyarakat.lelang.search')); ?>" style="display:block; text-align:center; margin-top:8px; font-size:12px; color:#64748B; text-decoration:none;">Reset Filter</a>
        </form>
    </div>

    
    <div>
        <div style="font-size:14px; color:#64748B; margin-bottom:16px;">Ditemukan <strong><?php echo e($lelang->total()); ?></strong> lelang</div>
        <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:16px;">
            <?php $__empty_1 = true; $__currentLoopData = $lelang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="background:white; border-radius:12px; border:1px solid #E2E8F0; overflow:hidden;">
                <div style="height:140px; background:linear-gradient(135deg,#EEF2FF,#E0E7FF); display:flex; align-items:center; justify-content:center; position:relative;">
                    <?php if($item->barang->foto_barang): ?>
                    <img src="<?php echo e($item->barang->foto_url); ?>" style="width:100%; height:100%; object-fit:cover;">
                    <?php else: ?>
                    <span style="font-size:40px;"><i class="bi bi-tag-fill" style="color:#A5B4FC;"></i></span>
                    <?php endif; ?>
                    <span style="position:absolute; top:8px; left:8px; background:<?php echo e($item->status==='berlangsung' ? '#ECFDF5' : '#EFF6FF'); ?>; color:<?php echo e($item->status==='berlangsung' ? '#059669' : '#2563EB'); ?>; padding:2px 8px; border-radius:50px; font-size:10px; font-weight:700;">
                        <?php if($item->status==='berlangsung'): ?>
                            <i class="bi bi-circle-fill"></i> Berlangsung
                        <?php else: ?>
                            <i class="bi bi-circle-fill"></i> Akan Dibuka
                        <?php endif; ?>
                    </span>
                </div>
                <div style="padding:14px;">
                    <div style="font-size:14px; font-weight:800; margin-bottom:4px;"><?php echo e($item->barang->nama_barang); ?></div>
                    <div style="font-size:16px; font-weight:800; color:#F59E0B; margin-bottom:10px;">Rp <?php echo e(number_format($item->barang->harga_awal,0,',','.')); ?></div>
                    <a href="<?php echo e(route('masyarakat.lelang.show', $item->id_lelang)); ?>" style="display:block; text-align:center; padding:8px; background:#4F46E5; color:white; border-radius:8px; font-size:12px; font-weight:700; text-decoration:none;">Lihat Detail</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="grid-column:1/-1; text-align:center; padding:60px; color:#64748B;">
                <div style="font-size:48px; margin-bottom:12px;"><i class="bi bi-search"></i></div>
                <p style="font-size:16px; font-weight:600;">Tidak ada lelang yang sesuai.</p>
            </div>
            <?php endif; ?>
        </div>
        <div style="margin-top:20px;"><?php echo e($lelang->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-masyarakat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/masyarakat/lelang/search.blade.php ENDPATH**/ ?>
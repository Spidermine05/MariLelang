<?php if($paginator->hasPages()): ?>
<nav style="display:flex; align-items:center; gap:4px; flex-wrap:wrap; margin-top:16px;">

    
    <?php if($paginator->onFirstPage()): ?>
        <span style="padding:5px 11px; font-size:12px; font-weight:600; border-radius:6px; border:1px solid var(--border); background:white; color:#cbd5e1; cursor:not-allowed;">‹ Prev</span>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>" style="padding:5px 11px; font-size:12px; font-weight:600; border-radius:6px; border:1px solid var(--border); background:white; color:var(--text-muted); text-decoration:none;">‹ Prev</a>
    <?php endif; ?>

    
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_string($element)): ?>
            <span style="padding:5px 8px; font-size:12px; color:var(--text-muted);">...</span>
        <?php endif; ?>
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <span style="padding:5px 11px; font-size:12px; font-weight:700; border-radius:6px; border:1px solid var(--brand); background:var(--brand); color:white;"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($url); ?>" style="padding:5px 11px; font-size:12px; font-weight:600; border-radius:6px; border:1px solid var(--border); background:white; color:var(--text-muted); text-decoration:none;"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>" style="padding:5px 11px; font-size:12px; font-weight:600; border-radius:6px; border:1px solid var(--border); background:white; color:var(--text-muted); text-decoration:none;">Next ›</a>
    <?php else: ?>
        <span style="padding:5px 11px; font-size:12px; font-weight:600; border-radius:6px; border:1px solid var(--border); background:white; color:#cbd5e1; cursor:not-allowed;">Next ›</span>
    <?php endif; ?>

</nav>
<?php endif; ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>
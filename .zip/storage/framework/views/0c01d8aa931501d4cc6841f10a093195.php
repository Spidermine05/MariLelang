<?php $__env->startSection('title', 'Riwayat Penawaran'); ?>
<?php $__env->startSection('content'); ?>
<div style="padding:24px;">
    <h2 style="font-size:20px; font-weight:800; margin-bottom:20px;">Riwayat Penawaran Saya</h2>
    <div style="background:white; border-radius:14px; border:1px solid #E2E8F0; overflow:hidden;">
        <table style="width:100%; border-collapse:collapse; font-size:13px;">
            <thead><tr style="background:#F8FAFF;">
                <?php $__currentLoopData = ['Barang','Harga Tawar','Waktu','Status Lelang','Status Bid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:#64748B; font-size:11px; text-transform:uppercase;"><?php echo e($h); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $penawaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="border-top:1px solid #E2E8F0;">
                    <td style="padding:12px 16px; font-weight:700;"><?php echo e($p->lelang?->barang?->nama_barang ?? '—'); ?></td>
                    <td style="padding:12px 16px; font-weight:800; color:#4F46E5;">Rp <?php echo e(number_format($p->harga_tawar,0,',','.')); ?></td>
                    <td style="padding:12px 16px; color:#64748B;"><?php echo e($p->waktu_tawar?->format('d/m/Y H:i')); ?></td>
                    <td style="padding:12px 16px;">
                        <?php $sc=['dibuka'=>['#EFF6FF','#2563EB'],'berlangsung'=>['#ECFDF5','#059669'],'ditutup'=>['#F1F5F9','#64748B']]; [$sb,$sf]=$sc[$p->lelang?->status??'ditutup']??['#F1F5F9','#64748B']; ?>
                        <span style="background:<?php echo e($sb); ?>; color:<?php echo e($sf); ?>; padding:3px 10px; border-radius:50px; font-size:11px; font-weight:700;"><?php echo e(ucfirst($p->lelang?->status ?? '—')); ?></span>
                    </td>
                    <td style="padding:12px 16px;">
                        <?php $bc=['aktif'=>['#EEF2FF','#4F46E5'],'menang'=>['#ECFDF5','#059669'],'kalah'=>['#FEF2F2','#DC2626']]; [$bb,$bf]=$bc[$p->status_tawar]??['#F1F5F9','#64748B']; ?>
                        <span style="background:<?php echo e($bb); ?>; color:<?php echo e($bf); ?>; padding:3px 10px; border-radius:50px; font-size:11px; font-weight:700;"><?php echo e(ucfirst($p->status_tawar)); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" style="padding:40px; text-align:center; color:#64748B;">Belum ada riwayat penawaran.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;"><?php echo e($penawaran->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-masyarakat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/masyarakat/penawaran/riwayat.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Laporan Saya'); ?>
<?php $__env->startSection('content'); ?>
<div style="padding:24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2 style="font-size:20px; font-weight:800;">Laporan Penawaran Saya</h2>
        <a href="<?php echo e(route('masyarakat.laporan.export')); ?>" style="padding:8px 16px; background:#ECFDF5; color:#059669; border-radius:8px; font-size:13px; font-weight:700; text-decoration:none;"><i class="bi bi-download"></i> Export PDF</a>
    </div>

    <?php
        $menang = $penawaran->where('status_tawar','menang')->count();
        $kalah  = $penawaran->where('status_tawar','kalah')->count();
        $aktif  = $penawaran->where('status_tawar','aktif')->count();
    ?>
    <div class="stat-grid" style="grid-template-columns:repeat(3,1fr); margin-bottom:24px;">
        <div style="background:white; border-radius:12px; border:1px solid #E2E8F0; padding:20px; text-align:center;">
            <div style="font-size:28px; margin-bottom:6px;"><i class="bi bi-trophy-fill" style="color:#059669;"></i></div>
            <div style="font-size:32px; font-weight:800; color:#059669;"><?php echo e($menang); ?></div>
            <div style="font-size:12px; color:#64748B; font-weight:600; text-transform:uppercase;">Menang</div>
        </div>
        <div style="background:white; border-radius:12px; border:1px solid #E2E8F0; padding:20px; text-align:center;">
            <div style="font-size:28px; margin-bottom:6px;"><i class="bi bi-x-circle-fill" style="color:#DC2626;"></i></div>
            <div style="font-size:32px; font-weight:800; color:#DC2626;"><?php echo e($kalah); ?></div>
            <div style="font-size:12px; color:#64748B; font-weight:600; text-transform:uppercase;">Kalah</div>
        </div>
        <div style="background:white; border-radius:12px; border:1px solid #E2E8F0; padding:20px; text-align:center;">
            <div style="font-size:28px; margin-bottom:6px;"><i class="bi bi-hourglass-split" style="color:#4F46E5;"></i></div>
            <div style="font-size:32px; font-weight:800; color:#4F46E5;"><?php echo e($aktif); ?></div>
            <div style="font-size:12px; color:#64748B; font-weight:600; text-transform:uppercase;">Aktif</div>
        </div>
    </div>

    <div style="background:white; border-radius:14px; border:1px solid #E2E8F0; overflow:hidden;">
        <table style="width:100%; border-collapse:collapse; font-size:13px;">
            <thead><tr style="background:#F8FAFF;">
                <?php $__currentLoopData = ['Barang','Harga Tawar','Waktu','Status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:#64748B; font-size:11px; text-transform:uppercase;"><?php echo e($h); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $penawaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="border-top:1px solid #E2E8F0;">
                    <td style="padding:12px 16px; font-weight:700;"><?php echo e($p->lelang?->barang?->nama_barang ?? '—'); ?></td>
                    <td style="padding:12px 16px; font-weight:800; color:#4F46E5;">Rp <?php echo e(number_format($p->harga_tawar,0,',','.')); ?></td>
                    <td style="padding:12px 16px; color:#64748B;"><?php echo e($p->waktu_tawar?->format('d/m/Y H:i')); ?></td>
                    <td style="padding:12px 16px;">
                        <?php $bc=['aktif'=>['#EEF2FF','#4F46E5'],'menang'=>['#ECFDF5','#059669'],'kalah'=>['#FEF2F2','#DC2626']]; [$bb,$bf]=$bc[$p->status_tawar]??['#F1F5F9','#64748B']; ?>
                        <span style="background:<?php echo e($bb); ?>; color:<?php echo e($bf); ?>; padding:3px 10px; border-radius:50px; font-size:11px; font-weight:700;"><?php echo e(ucfirst($p->status_tawar)); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" style="padding:40px; text-align:center; color:#64748B;">Belum ada data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;"><?php echo e($penawaran->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-masyarakat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/masyarakat/laporan/index.blade.php ENDPATH**/ ?>
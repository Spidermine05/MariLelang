<?php $__env->startSection('title', 'Kelola Kategori'); ?>
<?php $__env->startSection('content'); ?>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h2 style="font-size:20px; font-weight:800;">Kelola Kategori</h2>
    <a href="<?php echo e(route('admin.kategori.create')); ?>" style="padding:8px 18px; background:var(--brand); color:white; border-radius:8px; font-size:13px; font-weight:700; text-decoration:none;">+ Tambah Kategori</a>
</div>
<div style="background:white; border-radius:12px; border:1px solid var(--border); overflow:hidden;">
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <thead><tr style="background:var(--bg);">
            <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Nama Kategori</th>
            <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Deskripsi</th>
            <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Jumlah Barang</th>
            <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Aksi</th>
        </tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr style="border-top:1px solid var(--border);">
                <td style="padding:12px 16px; font-weight:700;"><?php echo e($k->nama_kategori); ?></td>
                <td style="padding:12px 16px; color:var(--text-muted);"><?php echo e($k->deskripsi_kategori ?? '—'); ?></td>
                <td style="padding:12px 16px;"><span style="background:#EEF2FF; color:var(--brand); padding:3px 10px; border-radius:50px; font-size:12px; font-weight:700;"><?php echo e($k->barang_count); ?></span></td>
                <td style="padding:12px 16px;">
                    <div style="display:flex; gap:6px;">
                        <a href="<?php echo e(route('admin.kategori.edit', $k->id_kategori)); ?>" style="padding:5px 10px; background:#EEF2FF; color:var(--brand); border-radius:6px; font-size:12px; font-weight:700; text-decoration:none;">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.kategori.destroy', $k->id_kategori)); ?>" onsubmit="return confirm('Hapus kategori ini?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="padding:5px 10px; background:#FEF2F2; color:#DC2626; border:none; border-radius:6px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;">Hapus</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" style="padding:40px; text-align:center; color:var(--text-muted);">Belum ada kategori.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div style="margin-top:16px;"><?php echo e($kategori->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>
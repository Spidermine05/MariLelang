<?php $__env->startSection('title', 'Manajemen Lelang'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h2 style="font-size:20px; font-weight:800;">Manajemen Lelang</h2>
    <a href="<?php echo e(route('petugas.lelang.create')); ?>" style="padding:8px 18px; background:var(--brand); color:white; border-radius:8px; font-size:13px; font-weight:700; text-decoration:none;">+ Buat Lelang</a>
</div>

<div style="background:white; border-radius:12px; border:1px solid var(--border); overflow:hidden;">
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <thead>
            <tr style="background:var(--bg);">
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Barang</th>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Status</th>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Waktu Mulai</th>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Waktu Selesai</th>
                <th style="padding:12px 16px; text-align:left; font-weight:700; color:var(--text-muted); font-size:11px; text-transform:uppercase;">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $lelang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $statusMap = [
                    'dibuka'=>['#EFF6FF','#2563EB','<i class="bi bi-circle-fill"></i> Dibuka'],
                    'berlangsung'=>['#ECFDF5','#059669','<i class="bi bi-circle-fill"></i> Berlangsung'],
                    'ditutup'=>['#F1F5F9','#64748B','<i class="bi bi-circle-fill"></i> Ditutup']
                ];
                [$bg,$fg,$label] = $statusMap[$item->status] ?? ['#F1F5F9','#64748B',$item->status];
            ?>
            <tr style="border-top:1px solid var(--border);">
                <td style="padding:12px 16px; font-weight:700;"><?php echo e($item->barang?->nama_barang ?? '—'); ?></td>
                <td style="padding:12px 16px;">
                    <span style="background:<?php echo e($bg); ?>; color:<?php echo e($fg); ?>; padding:3px 10px; border-radius:50px; font-size:11px; font-weight:700;"><?php echo $label; ?></span>
                </td>
                <td style="padding:12px 16px; color:var(--text-muted);"><?php echo e($item->waktu_mulai?->format('d/m/Y H:i') ?? '—'); ?></td>
                <td style="padding:12px 16px; color:var(--text-muted);"><?php echo e($item->waktu_selesai?->format('d/m/Y H:i') ?? '—'); ?></td>
                <td style="padding:12px 16px;">
                    <div style="display:flex; gap:6px; flex-wrap:wrap;">
                        <a href="<?php echo e(route('petugas.lelang.show', $item->id_lelang)); ?>" style="padding:5px 10px; background:#EEF2FF; color:var(--brand); border-radius:6px; font-size:12px; font-weight:700; text-decoration:none;">Detail</a>
                        <?php if($item->status === 'dibuka'): ?>
                        <form method="POST" action="<?php echo e(route('petugas.lelang.buka', $item->id_lelang)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit" style="padding:5px 10px; background:#ECFDF5; color:#059669; border:none; border-radius:6px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;">Buka</button>
                        </form>
                        <?php elseif($item->status === 'berlangsung'): ?>
                        <form method="POST" action="<?php echo e(route('petugas.lelang.tutup', $item->id_lelang)); ?>" onsubmit="return confirm('Tutup lelang ini sekarang?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit" style="padding:5px 10px; background:#FEF2F2; color:#DC2626; border:none; border-radius:6px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;">Tutup</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" style="padding:40px; text-align:center; color:var(--text-muted);">Belum ada lelang.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div style="margin-top:16px;"><?php echo e($lelang->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MariLelang\resources\views/petugas/lelang/index.blade.php ENDPATH**/ ?>